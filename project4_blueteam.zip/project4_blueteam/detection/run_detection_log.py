"""
Screenshot #5 -- "Detection" in the Blue Team sense usually means more
than a bare BLOCKED/ALLOWED verdict: a security-monitoring view with
severity, a rule/signature ID, and enough context for an analyst to
triage without opening raw logs. This script re-reads project4's
guardrail-demo log (produced by run_guardrail_demo.py) and reformats
every BLOCKED entry into SIEM-style alert lines -- the kind you'd see
in Splunk/Sentinel/an ELK dashboard.

Run AFTER run_guardrail_demo.py:
    python run_detection_log.py
"""
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
SOURCE_LOG = os.path.abspath(os.path.join(HERE, "..", "..", "logs", "project4_guardrail_demo.jsonl"))
ALERT_LOG = os.path.abspath(os.path.join(HERE, "..", "..", "logs", "detection_alerts.log"))

SEVERITY_BY_RULE_PREFIX = {
    "IN-01": "HIGH",    # credential exfiltration attempt
    "IN-02": "HIGH",    # fake system/orchestrator authority
    "IN-03": "MEDIUM",  # role override attempt
    "IN-04": "MEDIUM",  # ignore-prior-instructions
    "IN-05": "MEDIUM",  # system prompt extraction attempt
    "IN-06": "LOW",     # suffix injection marker
    "IN-07": "CRITICAL",  # privileged action claim
    "IN-08": "HIGH",    # RAG-embedded tool-call instruction
    "OUT-01": "CRITICAL",  # JWT actually leaked
    "OUT-02": "CRITICAL",  # known secret actually leaked
    "OUT-03": "CRITICAL",  # unauthorized action about to execute
    "OUT-04": "HIGH",      # role-change claim in response
}


def main():
    if not os.path.exists(SOURCE_LOG):
        print(f"Source log not found: {SOURCE_LOG}")
        print("Run project4_blueteam/run_guardrail_demo.py first.")
        return

    alerts = []
    with open(SOURCE_LOG, "r", encoding="utf-8") as f:
        for line in f:
            entry = json.loads(line)
            if entry.get("verdict") != "BLOCKED":
                continue
            rule_id = entry.get("rule_id", "UNKNOWN")
            prefix = rule_id.split("_")[0] if rule_id else "UNKNOWN"
            severity = SEVERITY_BY_RULE_PREFIX.get(prefix, "MEDIUM")
            alerts.append({
                "timestamp": entry["timestamp"],
                "severity": severity,
                "rule_id": rule_id,
                "stage": entry.get("stage"),
                "attack_label": entry.get("label"),
                "reason": entry.get("reason"),
                "matched_snippet": (entry.get("matched_text") or "")[:80],
            })

    with open(ALERT_LOG, "w", encoding="utf-8") as f:
        f.write("=" * 100 + "\n")
        f.write("AI SECURITY MONITORING -- GUARDRAIL ALERT FEED\n")
        f.write("=" * 100 + "\n\n")
        for a in alerts:
            f.write(
                f"[{a['timestamp']}] SEVERITY={a['severity']:<8} "
                f"RULE={a['rule_id']:<35} STAGE={a['stage'] or '-':<7}\n"
                f"    source_test : {a['attack_label']}\n"
                f"    reason      : {a['reason']}\n"
                f"    matched     : {a['matched_snippet']!r}\n\n"
            )
        f.write(f"Total alerts: {len(alerts)}\n")
        by_sev = {}
        for a in alerts:
            by_sev[a["severity"]] = by_sev.get(a["severity"], 0) + 1
        for sev in ("CRITICAL", "HIGH", "MEDIUM", "LOW"):
            if sev in by_sev:
                f.write(f"  {sev}: {by_sev[sev]}\n")

    print(f"Wrote {len(alerts)} alerts to {ALERT_LOG}")
    with open(ALERT_LOG, "r", encoding="utf-8") as f:
        print(f.read())


if __name__ == "__main__":
    main()
