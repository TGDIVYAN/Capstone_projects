"""
GuardedClient -- wraps the Project 3 LLMClient with:
  1. An INPUT filter (checked before the call is sent)
  2. An OUTPUT filter (checked after the model responds, defense-in-depth)

Every call produces a verdict dict:
    {
        "verdict": "BLOCKED" | "ALLOWED",
        "stage": "input" | "output" | None,
        "rule_id": "...", "reason": "...", "matched_text": "...",
        "response": "<model response, or a BLOCKED placeholder>",
    }

This is what gets logged for screenshot #1 (guardrail blocking) and is
also what the post-defense success-matrix script calls instead of the
raw LLMClient, so you get a clean before/after comparison.
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", "common"))
from llm_client import LLMClient  # noqa: E402
from rules import INPUT_RULES, OUTPUT_RULES, scan  # noqa: E402


class GuardedClient:
    def __init__(self, model: str = None, max_tokens: int = 1024):
        self._inner = LLMClient(model=model, max_tokens=max_tokens) if model else LLMClient(max_tokens=max_tokens)

    @property
    def live(self) -> bool:
        return self._inner.live

    def call(self, system_prompt: str, user_content: str) -> dict:
        # 1. Input filter -- scan the untrusted content before it ever reaches the model.
        hit = scan(user_content, INPUT_RULES)
        if hit:
            rule_id, reason, matched = hit
            return {
                "verdict": "BLOCKED",
                "stage": "input",
                "rule_id": rule_id,
                "reason": reason,
                "matched_text": matched,
                "response": f"[BLOCKED at input by {rule_id}: {reason}]",
            }

        # 2. Call the underlying model.
        raw_response = self._inner.call(system_prompt, user_content)

        # 3. Output filter -- defense-in-depth backstop.
        hit = scan(raw_response, OUTPUT_RULES)
        if hit:
            rule_id, reason, matched = hit
            return {
                "verdict": "BLOCKED",
                "stage": "output",
                "rule_id": rule_id,
                "reason": reason,
                "matched_text": matched,
                "response": f"[BLOCKED at output by {rule_id}: {reason} "
                            f"(raw response withheld)]",
            }

        return {
            "verdict": "ALLOWED",
            "stage": None,
            "rule_id": None,
            "reason": None,
            "matched_text": None,
            "response": raw_response,
        }
