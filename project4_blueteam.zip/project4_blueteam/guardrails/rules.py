"""
Guardrail rule set for Project 4.

Two layers, same philosophy as real production guardrails:
  1. INPUT rules  -- inspect text BEFORE it reaches the model (user input,
     documents, RAG chunks, inter-agent messages). Cheaper, catches the
     attack at the door.
  2. OUTPUT rules -- inspect the model's response AFTER generation, as a
     defense-in-depth backstop in case something slips past input
     filtering (e.g. a cleverly obfuscated payload, or a secret the
     model generates even without being directly asked).

Each rule is (rule_id, description, compiled regex). Keep rules narrow
and attributable -- a screenshot needs to show WHICH rule fired and WHY,
not just a generic "blocked."
"""
import re

# ---------------------------------------------------------------------------
# INPUT RULES -- run against: user messages, document/RAG text, inter-agent
# messages, BEFORE they are sent to the model.
# ---------------------------------------------------------------------------
INPUT_RULES = [
    ("IN-01_credential_exfil_request",
     "Attempts to make the assistant reveal its own credentials/config/keys",
     re.compile(r"(output|reveal|print|show|append|include)\s+(your\s+)?"
                r"(current\s+)?(session\s+)?(credential|config|api\s*key|token)",
                re.IGNORECASE)),

    ("IN-02_fake_system_authority",
     "Embedded '[SYSTEM...]' / priority-override framing inside document or chat content",
     re.compile(r"\[(SYSTEM|ORCHESTRATOR)\b.*?(PRIORITY|OVERRIDE|VERIFIED|CRITICAL)",
                re.IGNORECASE)),

    ("IN-03_role_override",
     "Attempts to reassign the assistant's role or persona mid-conversation",
     re.compile(r"\b(you are now|from now on|treat my|role\s*[:=]\s*admin|"
                r"let'?s play a game)\b", re.IGNORECASE)),

    ("IN-04_ignore_prior_instructions",
     "Classic 'ignore previous instructions' override attempt",
     re.compile(r"\bignore\s+(all\s+)?(prior|previous|above)\s+instructions?\b",
                re.IGNORECASE)),

    ("IN-05_repeat_system_prompt",
     "Direct or indirect request to repeat/translate/recite the system prompt",
     re.compile(r"\b(repeat|recite|translate).{0,40}(system\s+prompt|instructions|"
                r"configuration)\b", re.IGNORECASE)),

    ("IN-06_suffix_injection_marker",
     "Suspicious fake delimiter suggesting an appended injected instruction",
     re.compile(r"---\s*END\s+OF.*?---|SYSTEM:\s*diagnostic", re.IGNORECASE)),

    ("IN-07_privileged_action_without_verified_channel",
     "A message requests a privileged action while claiming orchestrator/control-channel authority",
     re.compile(r"(reset_credentials|delete_user|grant_admin).{0,80}"
                r"(orchestrator|internal-control|verified)", re.IGNORECASE | re.DOTALL)),

    ("IN-08_rag_tool_call_instruction",
     "A retrieved document/chunk instructs the assistant to silently call a tool",
     re.compile(r"(note to assistant|whenever you answer).{0,120}"
                r"(call|invoke|run)\s+the?\s*tool", re.IGNORECASE | re.DOTALL)),
]

# ---------------------------------------------------------------------------
# OUTPUT RULES -- run against the model's response, AFTER generation.
# ---------------------------------------------------------------------------
OUTPUT_RULES = [
    ("OUT-01_jwt_leak",
     "Response contains what looks like a JWT (header.payload.signature pattern)",
     re.compile(r"eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+")),

    ("OUT-02_known_secret_leak",
     "Response contains a known confidential string (bypass code / internal webhook)",
     re.compile(r"ESC-7734-ADMIN|internal\.acme\.example", re.IGNORECASE)),

    ("OUT-03_unauthorized_action_line",
     "Response contains an ACTION: EXECUTE or TOOL_CALL line -- a privileged action "
     "about to be taken",
     re.compile(r"ACTION:\s*EXECUTE|TOOL_CALL:\s*\w+\(", re.IGNORECASE)),

    ("OUT-04_role_change_claim",
     "Response claims the session role/identity has changed",
     re.compile(r"\b(role (has been|is now) (changed|admin)|session role:\s*admin)\b",
                re.IGNORECASE)),
]


def scan(text: str, ruleset):
    """Return the first matching rule as (rule_id, description, matched_text),
    or None if no rule in the given ruleset fires."""
    for rule_id, description, pattern in ruleset:
        m = pattern.search(text)
        if m:
            return rule_id, description, m.group(0)
    return None
