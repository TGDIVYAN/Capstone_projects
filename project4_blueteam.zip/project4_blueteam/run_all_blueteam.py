"""
Runs the full Project 4 pipeline in order:
  1. Guardrail demo (blocks Project 3 payloads)      -> screenshots 1-2
  2. Post-defense success matrix                      -> screenshot 4
  3. Detection alert log (reads output of step 1)     -> screenshot 5
  4. Dashboard build (reads output of steps 2 and 3)   -> screenshot 6
  5. Hardening demo (before/after on Attack 3)         -> screenshot 7

Run from the project4_blueteam directory, or anywhere -- paths are
resolved relative to this file.
"""
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))

STEPS = [
    os.path.join(ROOT, "run_guardrail_demo.py"),
    os.path.join(ROOT, "run_success_matrix_post_defense.py"),
    os.path.join(ROOT, "detection", "run_detection_log.py"),
    os.path.join(ROOT, "dashboard", "build_dashboard.py"),
    os.path.join(ROOT, "hardening", "run_hardening_demo.py"),
]

for script in STEPS:
    print("\n" + "#" * 80)
    print(f"# Running: {script}")
    print("#" * 80)
    subprocess.run([sys.executable, script], cwd=os.path.dirname(script), check=False)

print("\nAll done. Check ../logs/ for the detailed logs, and "
      "dashboard/dashboard.html in a browser for the visual summary.")
