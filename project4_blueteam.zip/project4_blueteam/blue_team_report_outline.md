# Project 4 — Blue Team Report: Guardrails, Hardening and Detection

Fill in the bracketed parts with your own real numbers/screenshots as
you go. This mirrors the structure graders expect for a blue-team
report: defenses built, validated against real red-team data, with
honest before/after metrics.

## 1. Executive Summary
- Scope: defended against the 4 attacks demonstrated in Project 3
  (indirect injection, agent identity spoofing, system prompt
  extraction, RAG poisoning), tested against [model name/version].
- Headline result: attack success rate dropped from [pre-defense %s]
  to [post-defense %s] after adding input/output guardrails.
- Residual risk: [name whichever attack still had a non-zero success
  rate after defenses — be honest here, a report claiming 100%
  effectiveness reads as unverified].

## 2. Defense Architecture
- **Input filtering** (`guardrails/rules.py`, `INPUT_RULES`): 8 rules
  catching credential-exfil requests, fake system/orchestrator
  framing, role overrides, ignore-prior-instruction patterns, system
  prompt recitation requests, suffix-injection markers, unverified
  privileged-action claims, and RAG-embedded tool-call instructions.
- **Output filtering** (`OUTPUT_RULES`): 4 rules as a defense-in-depth
  backstop — JWT pattern leak, known-secret leak, unauthorized
  ACTION/TOOL_CALL lines, and role-change claims.
- **Prompt hardening** (`hardening/run_hardening_demo.py`): spotlighting
  delimiters around sensitive config, secret replaced with an opaque
  reference token, explicit anti-repetition instruction.
- Diagram (optional, draw this yourself):
  `User/Document input -> [INPUT FILTER] -> Model -> [OUTPUT FILTER] -> Response`

## 3. Before / After Results

| Attack | Pre-defense success rate | Post-defense success rate | Reduction |
|---|---|---|---|
| Indirect Prompt Injection | [from Project 3 CSV] | [from Project 4 CSV] | |
| Agent Identity Spoofing | | | |
| System Prompt Extraction | | | |
| RAG Poisoning / MCP Abuse | | | |

(Pull these straight from `logs/success_matrix_pre_defense.csv` and
`logs/success_matrix_post_defense.csv`.)

## 4. Detection Capability
- Alert volume by severity: [from `logs/detection_alerts.log` totals]
- Example alert (paste one from the log): rule ID, severity, matched
  snippet, which test triggered it.
- Gaps: note any attack that succeeded WITHOUT generating an alert —
  that's a detection blind spot worth calling out explicitly.

## 5. Hardening Validation
- Before: [leaked / not leaked] on the `repeat_back` extraction technique
  against the original system prompt.
- After: [leaked / not leaked] against the hardened system prompt.
- If it still leaked after hardening, say so plainly and explain why
  (e.g. small/local models don't always follow complex meta-instructions
  reliably) — this is a legitimate, reportable limitation, not a failure
  to hide.

## 6. Limitations
- Model used: [name] — note if it's a small/local model, since capability
  limits (not just safety behavior) can affect both attack and defense
  results.
- Regex-based filtering catches known patterns; a determined attacker
  could likely find phrasing that evades these specific rules (this is
  true of all keyword/pattern-based guardrails — mention this honestly
  rather than claiming the filters are complete).
- Sample size: [N] runs per attack in each success matrix — small N
  means the percentages are indicative, not statistically precise.

## 7. Recommendations for Production
1. Replace regex-based input filtering with a dedicated classifier
   model trained on injection/jailbreak examples (regex only catches
   patterns you anticipated).
2. Never place long-lived secrets directly in a system prompt; use
   short-lived, scope-limited tokens resolved server-side, never by
   the model itself.
3. Authenticate inter-agent messages cryptographically (signed tokens,
   mTLS) rather than relying on the model to judge sender identity
   from message content or tone.
