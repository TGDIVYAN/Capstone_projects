"""
Screenshot #6 -- builds a simple static HTML dashboard summarizing:
  - before/after attack success rates (from both success-matrix CSVs)
  - total alerts by severity (from detection_alerts.log)

Run AFTER run_success_matrix_post_defense.py and run_detection_log.py:
    python build_dashboard.py

Then open the generated dashboard.html in a browser and screenshot it.
"""
import csv
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
LOGS_DIR = os.path.abspath(os.path.join(HERE, "..", "..", "logs"))
PRE_CSV = os.path.join(LOGS_DIR, "success_matrix_pre_defense.csv")
POST_CSV = os.path.join(LOGS_DIR, "success_matrix_post_defense.csv")
ALERT_LOG = os.path.join(LOGS_DIR, "detection_alerts.log")
OUT_HTML = os.path.join(HERE, "dashboard.html")


def read_csv(path):
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def parse_alert_counts(path):
    counts = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}
    if not os.path.exists(path):
        return counts
    with open(path, "r", encoding="utf-8") as f:
        text = f.read()
    for sev in counts:
        m = re.search(rf"^\s*{sev}:\s*(\d+)", text, re.MULTILINE)
        if m:
            counts[sev] = int(m.group(1))
    return counts


def main():
    pre = {r["attack"]: r for r in read_csv(PRE_CSV)}
    post = {r["attack"]: r for r in read_csv(POST_CSV)}
    alert_counts = parse_alert_counts(ALERT_LOG)

    attack_names = sorted(set(pre) | set(post))
    rows_html = ""
    for name in attack_names:
        pre_rate = pre.get(name, {}).get("success_rate_pct", "N/A")
        post_rate = post.get(name, {}).get("success_rate_pct_after_defense", "N/A")
        blocked = post.get(name, {}).get("blocked", "N/A")
        rows_html += f"""
        <tr>
          <td>{name}</td>
          <td class="before">{pre_rate}%</td>
          <td class="after">{post_rate}%</td>
          <td>{blocked}</td>
        </tr>"""

    alert_html = "".join(
        f'<div class="pill {sev.lower()}">{sev}: {count}</div>'
        for sev, count in alert_counts.items()
    )

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>AI Identity Security -- Blue Team Dashboard</title>
<style>
  :root {{
    --bg: #0f1117; --panel: #171a23; --text: #e6e8ee; --muted: #9aa1b1;
    --border: #262a38; --before: #d9534f; --after: #3fb950; --accent: #5b8def;
  }}
  @media (prefers-color-scheme: light) {{
    :root {{ --bg: #f5f6f8; --panel: #ffffff; --text: #1b1e27; --muted: #5b6270; --border: #e2e4ea; }}
  }}
  * {{ box-sizing: border-box; }}
  body {{ margin:0; background:var(--bg); color:var(--text);
          font-family: -apple-system, Segoe UI, Roboto, Arial, sans-serif; padding: 24px; }}
  h1 {{ font-size: 1.4rem; margin-bottom: 4px; }}
  .sub {{ color: var(--muted); margin-bottom: 24px; }}
  .panel {{ background: var(--panel); border: 1px solid var(--border); border-radius: 10px;
            padding: 20px; margin-bottom: 20px; }}
  table {{ width: 100%; border-collapse: collapse; }}
  th, td {{ text-align: left; padding: 10px 12px; border-bottom: 1px solid var(--border); }}
  th {{ color: var(--muted); font-weight: 600; font-size: 0.85rem; text-transform: uppercase; }}
  td.before {{ color: var(--before); font-weight: 600; }}
  td.after {{ color: var(--after); font-weight: 600; }}
  .pill {{ display:inline-block; padding: 6px 14px; border-radius: 999px; margin-right: 8px;
           font-size: 0.85rem; font-weight: 600; }}
  .critical {{ background: #d9534f33; color: #ff6b66; }}
  .high {{ background: #e8862733; color: #ffab52; }}
  .medium {{ background: #e8c02733; color: #ffd866; }}
  .low {{ background: #3fb95033; color: #6fe085; }}
</style>
</head>
<body>
  <h1>AI Identity Security Capstone -- Blue Team Dashboard</h1>
  <div class="sub">Project 4: guardrail effectiveness &amp; alert summary</div>

  <div class="panel">
    <h2 style="margin-top:0;">Attack success rate: before vs after guardrails</h2>
    <table>
      <tr><th>Attack</th><th>Before (Project 3)</th><th>After (Project 4)</th><th>Blocked / runs</th></tr>
      {rows_html}
    </table>
  </div>

  <div class="panel">
    <h2 style="margin-top:0;">Alert feed summary</h2>
    {alert_html}
  </div>
</body>
</html>"""

    with open(OUT_HTML, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"Wrote {OUT_HTML}")
    print("Open it in a browser and screenshot it for requirement #6.")


if __name__ == "__main__":
    main()
