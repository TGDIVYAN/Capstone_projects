"""
Screenshots #1 and #2 -- replays the EXACT payloads from Project 3's
attacks 1-4 through the guardrail-wrapped client, and logs a verdict
for each: BLOCKED (with rule id + reason) or ALLOWED.

#1 asks for "at least 3 of the Project 3 attack payloads" blocked with
status+reason visible -- this script covers all of them, across both
input-stage and output-stage blocks, so you can pick whichever subset
of the log best demonstrates "3+ blocked with reason."

Run:
    python run_guardrail_demo.py
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "guardrails"))
sys.path.insert(0, os.path.join(HERE, "..", "common"))
sys.path.insert(0, os.path.join(HERE, "..", "project3_redteam", "attack1_indirect_injection"))
sys.path.insert(0, os.path.join(HERE, "..", "project3_redteam", "attack2_agent_spoofing"))
sys.path.insert(0, os.path.join(HERE, "..", "project3_redteam", "attack3_prompt_extraction"))
sys.path.insert(0, os.path.join(HERE, "..", "project3_redteam", "attack4_rag_poisoning"))

from guarded_client import GuardedClient  # noqa: E402
from logger import log_interaction        # noqa: E402

ATTACK_ID = "project4_guardrail_demo"


def run_case(client, label, system_prompt, user_content):
    result = client.call(system_prompt, user_content)
    log_interaction(
        ATTACK_ID, label, system_prompt, user_content, result["response"],
        extra={
            "verdict": result["verdict"],
            "stage": result["stage"],
            "rule_id": result["rule_id"],
            "reason": result["reason"],
            "matched_text": result["matched_text"],
        },
    )
    tag = result["verdict"]
    detail = f" [{result['rule_id']}: {result['reason']}]" if result["rule_id"] else ""
    print(f"  {label}: {tag}{detail}")
    return result


def main():
    client = GuardedClient()
    print(f"Guardrail client live: {client.live}\n")

    print("--- Attack 1 payloads (indirect injection) ---")
    import run_attack1 as a1
    for label, filename in a1.DOCS:
        with open(os.path.join(a1.DOC_DIR, filename), "r", encoding="utf-8") as f:
            doc_text = f.read()
        user_content = f"Please summarize this document in 3 bullet points.\n\n{doc_text}"
        run_case(client, f"attack1_{label}", a1.SYSTEM_PROMPT, user_content)

    print("\n--- Attack 2 payload (agent spoofing) ---")
    import run_attack2 as a2
    run_case(client, "attack2_spoofed_orchestrator",
              a2.AGENT_B_SYSTEM_PROMPT, a2.SPOOFED_MESSAGE)
    run_case(client, "attack2_control_unauthenticated",
              a2.AGENT_B_SYSTEM_PROMPT, a2.CONTROL_MESSAGE)

    print("\n--- Attack 3 payloads (prompt extraction) ---")
    import run_attack3 as a3
    for label, prompt in a3.TECHNIQUES:
        run_case(client, f"attack3_{label}", a3.SYSTEM_PROMPT, prompt)

    print("\n--- Attack 4 payload (RAG poisoning) ---")
    import run_attack4 as a4
    from knowledge_base import retrieve
    chunks = retrieve(a4.USER_QUERY, k=2)
    context_block = "\n\n".join(f"[{c['id']}] {c['text']}" for c in chunks)
    user_content = f"Context:\n{context_block}\n\nUser question: {a4.USER_QUERY}"
    run_case(client, "attack4_rag_poisoning", a4.SYSTEM_PROMPT, user_content)

    print("\nFull verdict log: logs/project4_guardrail_demo.log")


if __name__ == "__main__":
    main()
