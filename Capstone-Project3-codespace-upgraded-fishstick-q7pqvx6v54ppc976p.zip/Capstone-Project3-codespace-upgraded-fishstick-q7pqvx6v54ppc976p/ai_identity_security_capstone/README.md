# AI Identity Security Capstone — Project 3 (Red Team) Lab

A self-contained, runnable lab for the 5 Project 3 attacks: indirect
prompt injection, agent identity spoofing, system prompt extraction,
RAG poisoning / MCP abuse, and CVSS/ATLAS scoring.

**Why you still have to run this yourself:** the assignment grades
*verbatim evidence from your own session* (payloads, full raw
responses, timestamps, screenshots). Nobody — including an AI
assistant — can generate that evidence on your behalf; it has to come
from an actual model run on your machine. This lab does all the
plumbing (agents, payloads, logging, scoring scaffolding) so that part
takes you minutes, not hours.

## 1. Setup

```bash
cd ai_identity_security_capstone
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
export ANTHROPIC_API_KEY="sk-ant-..."   # get one at console.anthropic.com
```

No key yet? Every script still runs in **MOCK MODE** — it will print
and log a clearly-labeled placeholder instead of inventing a fake
"vulnerable" response. Use mock mode only to confirm the code runs
end-to-end; get a real key before capturing evidence for your report.

You can swap in a different provider's SDK by editing
`common/llm_client.py` — the rest of the lab only calls
`client.call(system_prompt, user_content)` and doesn't care which
provider is behind it.

## 2. Run the attacks

Individually:
```bash
cd project3_redteam/attack1_indirect_injection && python run_attack1.py
cd ../attack2_agent_spoofing && python run_attack2.py
cd ../attack3_prompt_extraction && python run_attack3.py
cd ../attack4_rag_poisoning && python run_attack4.py
cd ../success_matrix && python run_success_matrix.py 5
```

Or all at once from the project root:
```bash
python run_all.py
```

Every run appends to `logs/<attack_id>.log` (human-readable — open this
for your screenshots) and `logs/<attack_id>.jsonl` (structured, in case
you want to post-process or chart it).

## 3. Attack 5 (CVSS + ATLAS) — manual step

Open `project3_redteam/attack5_cvss_atlas/cvss_and_atlas_notes.md`.
It has starting-point CVSS vectors and candidate ATLAS technique IDs for
each attack, but **you** fill in the real base-metric choices in the
first.org calculator based on what your actual logs show, and verify
the ATLAS technique IDs on atlas.mitre.org (IDs shift between ATLAS
versions, so don't cite from memory). The CSV template in the same
folder is ready to fill in as your findings table (screenshot #7).

## 4. Screenshot checklist → file mapping

| # | Required screenshot | Where to find it |
|---|---|---|
| 1 | JWT exposed via indirect injection | `logs/attack1_indirect_injection.log` |
| 2 | Agent B executes privileged action after spoofed message | `logs/attack2_agent_spoofing.log` |
| 3 | Partial system prompt leaking | `logs/attack3_prompt_extraction.log` |
| 4 | Model acts on poisoned RAG chunk | `logs/attack4_rag_poisoning.log` |
| 5 | CVSS calculator, highest-severity finding | first.org calculator (manual) |
| 6 | MITRE ATLAS technique page | atlas.mitre.org (manual) |
| 7 | CVSS findings table, all 5 attacks | `attack5_cvss_atlas/findings_table_template.csv` filled in |
| 8 | Success-rate matrix before defenses | `logs/success_matrix_pre_defense.csv` |

## 5. Report

Use this outline:
1. Executive summary
2. Methodology / lab setup (you can lift most of this README)
3. One finding page per attack: payload verbatim, response verbatim,
   CVSS vector + score, ATLAS ID, kill chain narrative
4. Top 3 hardening recommendations, e.g.:
   - Separate untrusted document/RAG content from instructions with
     explicit delimiters, and never let model output from a "data"
     region be treated as a new instruction (prompt-injection
     spotlighting).
   - Authenticate inter-agent messages cryptographically (signed
     tokens / mTLS) rather than trusting message *content* or tone to
     establish sender identity.
   - Never place long-lived credentials directly in a model's context;
     use short-lived, scope-limited tokens issued per tool call, and
     keep secrets out of the system prompt entirely where possible.

## 6. Project 4 (Blue Team) — what carries over

Project 4 asks you to show guardrails *blocking* at least 3 of these
same payloads. Reuse `common/llm_client.py` and the same payload files
from Attack 1, but wrap the call with an input/output filter (keyword
or classifier-based) before/after `client.call(...)`, and log a
`BLOCKED` status + reason the same way `logger.py` already does. Happy
to help build that layer next — it's a short follow-on to this code.
