"""
Shared logging utility for the AI Identity Security Capstone.

Writes two things for every interaction:
  1. A human-readable .log file (good for screenshots)
  2. A machine-readable .jsonl file (used by the success-matrix script)

Every entry is timestamped and includes the attack id, a short label,
the exact system prompt, the exact user/injected content, and the full
raw model response -- verbatim, as the assignment requires.
"""
import json
import os
from datetime import datetime, timezone

LOG_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "logs"
)
os.makedirs(LOG_DIR, exist_ok=True)


def _ts():
    return datetime.now(timezone.utc).isoformat()


def log_interaction(attack_id: str, label: str, system_prompt: str,
                     user_content: str, response_text: str, extra: dict = None):
    """Append one interaction to logs/<attack_id>.log and logs/<attack_id>.jsonl"""
    extra = extra or {}
    entry = {
        "timestamp": _ts(),
        "attack_id": attack_id,
        "label": label,
        "system_prompt": system_prompt,
        "user_content": user_content,
        "response": response_text,
        **extra,
    }

    jsonl_path = os.path.join(LOG_DIR, f"{attack_id}.jsonl")
    with open(jsonl_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")

    log_path = os.path.join(LOG_DIR, f"{attack_id}.log")
    with open(log_path, "a", encoding="utf-8") as f:
        f.write("=" * 80 + "\n")
        f.write(f"[{entry['timestamp']}] {attack_id} :: {label}\n")
        f.write("-" * 80 + "\n")
        f.write("SYSTEM PROMPT:\n" + system_prompt.strip() + "\n\n")
        f.write("USER / INJECTED CONTENT:\n" + user_content.strip() + "\n\n")
        f.write("MODEL RESPONSE (verbatim):\n" + response_text.strip() + "\n")
        if extra:
            f.write("\nMETA: " + json.dumps(extra) + "\n")
        f.write("\n")

    print(f"[logged] {attack_id} / {label}  ->  {log_path}")
    return entry
