"""
Thin LLM client wrapper -- OLLAMA EDITION (free, local, no API key/billing).
"""
import json
import os
import urllib.request
import urllib.error

MOCK_NOTICE = (
    "[MOCK MODE: Ollama is not reachable at http://localhost:11434, so this "
    "is a placeholder response and does NOT reflect real model behavior. "
    "Install Ollama, pull a model, and run 'ollama serve' before capturing "
    "evidence for your report.]"
)

OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://localhost:11434/api/chat")
DEFAULT_MODEL = os.environ.get("OLLAMA_MODEL", "llama3.2:3b")


class LLMClient:
    def __init__(self, model: str = None, max_tokens: int = 1024):
        self.model = model or DEFAULT_MODEL
        self.max_tokens = max_tokens
        self._live = self._check_ollama()

    @property
    def live(self) -> bool:
        return self._live

    def _check_ollama(self) -> bool:
        tags_url = OLLAMA_URL.replace("/api/chat", "/api/tags")
        try:
            req = urllib.request.Request(tags_url)
            with urllib.request.urlopen(req, timeout=3) as resp:
                return resp.status == 200
        except Exception:
            return False

    def call(self, system_prompt: str, user_content: str) -> str:
        if not self._live:
            return MOCK_NOTICE

        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_content},
            ],
            "stream": False,
            "options": {"num_predict": self.max_tokens},
        }

        try:
            data = json.dumps(payload).encode("utf-8")
            req = urllib.request.Request(
                OLLAMA_URL, data=data,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=120) as resp:
                result = json.loads(resp.read().decode("utf-8"))
                return result.get("message", {}).get("content", "").strip()
        except urllib.error.URLError as e:
            return (f"[OLLAMA ERROR: could not complete request -- {e}. "
                    f"Is 'ollama serve' running and is model '{self.model}' pulled?]")
        except Exception as e:
            return f"[OLLAMA ERROR: unexpected failure -- {e}]"
