"""
Convenience runner: executes attacks 1-4 in order, then the success
matrix. Equivalent to running each script individually, just saves you
typing four commands.

Run from the project root:
    python run_all.py
"""
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))

SCRIPTS = [
    os.path.join(ROOT, "project3_redteam", "attack1_indirect_injection", "run_attack1.py"),
    os.path.join(ROOT, "project3_redteam", "attack2_agent_spoofing", "run_attack2.py"),
    os.path.join(ROOT, "project3_redteam", "attack3_prompt_extraction", "run_attack3.py"),
    os.path.join(ROOT, "project3_redteam", "attack4_rag_poisoning", "run_attack4.py"),
    os.path.join(ROOT, "project3_redteam", "success_matrix", "run_success_matrix.py"),
]

for script in SCRIPTS:
    print("\n" + "#" * 80)
    print(f"# Running: {script}")
    print("#" * 80)
    subprocess.run([sys.executable, script], cwd=os.path.dirname(script), check=False)

print("\nAll done. Check the logs/ directory for .log, .jsonl, and the")
print("success_matrix_pre_defense.csv file.")
