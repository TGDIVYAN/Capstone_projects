# Project 1: Threat Model of the SecureNova AI Identity System

Files delivered with this report:

| File | Use |
|---|---|
| `SecureNova_ThreatDragon.json` | Import into OWASP Threat Dragon (DFD, trust boundaries, 72 STRIDE threats) |
| `SecureNova_Attack_Trees.drawio` | Open in draw.io (3 pages, one per attack tree) |
| `SecureNova_Threat_Model.xlsx` | Identity inventory, STRIDE matrix, risk register (16 threats), ATLAS mapping |

## 1. Identity inventory

| ID | Identity | Authentication | Privilege |
|---|---|---|---|
| ID-01 | Human user | OIDC SSO + MFA, short-lived session JWT | Low-Medium: own-tenant data, delegated agent use |
| ID-02 | Human admin | SSO + FIDO2 MFA, just-in-time PAM | High: IAM policy, vault, agent registry |
| ID-03 | AI agent identity | Workload identity (SPIFFE/cloud IAM), RFC 8693 token exchange with user `act` claim, 15-min tokens | Medium-High: tools and internal APIs on behalf of a user |
| ID-04 | OAuth M2M client | `client_credentials` with `private_key_jwt` or mTLS, audience-scoped tokens | High: service-to-service API access |
| ID-05 | LLM API key | Static bearer secret held in vault | High: spend, data sent to provider |
| ID-06 | RAG pipeline service identity | Workload identity; separate ingestion (write) and retrieval (read) roles | Medium-High: vector DB and document store |
| ID-07 | MCP server identity | mTLS + OAuth token validation, per-tool scopes | High: runs tools, reaches internal APIs |

## 2. Data flows and trust boundaries

- **TB1** User layer / Agent layer
- **TB2** Agent layer / Internal API layer
- **TB3** Platform / External (LLM provider, document sources, internet)

Flows F01-F12: User->Gateway/IdP, Gateway->Orchestrator, Orchestrator->LLM, Orchestrator->MCP, MCP->Internal APIs, Orchestrator->Retriever, Retriever->Vector DB, Ingestion->Vector DB, Doc sources->Ingestion, Services->Vault, Agent->IdP, Internal APIs->Audit log.

The complete 12 x 6 STRIDE matrix (all 72 cells populated) is in sheet `2_STRIDE_Matrix` and in the Threat Dragon model.

## 3. Attack trees (draw.io)

1. **LLM API key exfiltration via prompt injection**: AND of (injection executes) + (key reachable) + (exfil channel). Root risk 4 x 5 = 20.
2. **Agent identity spoofing for elevated scope**: OR of steal credential / abuse delegation / rogue registration. Root risk 4 x 5 = 20.
3. **RAG chunk poisoning**: AND of (corpus write access) + (chunk retrieved) + (agent obeys). Root risk 4 x 4 = 16.

Every leaf carries its own Likelihood x Impact score.

## 4. Risk-ranked register (Likelihood x Impact)

| Rank | ID | Threat | L | I | Score | Rating | Owner | ATLAS |
|---|---|---|---|---|---|---|---|---|
| 1 | T01 | LLM key exfiltrated via indirect prompt injection | 4 | 5 | 20 | Critical | Head of AI Platform | AML.T0051.001 |
| 1 | T05 | Confused deputy, agent token exceeds user scope | 4 | 5 | 20 | Critical | IAM Lead | AML.T0012 |
| 3 | T03 | Exfil via markdown/link rendering or outbound tool | 4 | 4 | 16 | High | AppSec Lead | AML.T0057 |
| 3 | T09 | Poisoned document ingested from shared source | 4 | 4 | 16 | High | Data Platform Lead | AML.T0070 |
| 5 | T04 | Agent credential stolen from env/logs/metadata | 3 | 5 | 15 | High | IAM Lead | AML.T0055 |
| 5 | T06 | Forged or replayed JWT accepted | 3 | 5 | 15 | High | IAM Lead | AML.T0073 |
| 5 | T10 | Over-privileged ingestion account overwrites chunks | 3 | 5 | 15 | High | Data Platform Lead | AML.T0070 |
| 5 | T12 | Poisoned chunk drives privileged tool call | 3 | 5 | 15 | High | Head of AI Platform | AML.T0070 |
| 5 | T13 | Cross-tenant retrieval leak | 3 | 5 | 15 | High | Data Platform Lead | AML.T0057 |
| 10 | T02 | System prompt / config extraction exposes secrets | 3 | 4 | 12 | High | Head of AI Platform | AML.T0051.000 |
| 10 | T07 | Rogue MCP server / tool poisoning | 3 | 4 | 12 | High | AppSec Lead | AML.T0053 |
| 10 | T11 | Crafted chunk engineered for retrieval | 3 | 4 | 12 | High | Data Platform Lead | AML.T0066 |
| 10 | T14 | No actor-chain audit trail | 4 | 3 | 12 | High | Security Operations Lead | AML.T0073 |
| 14 | T08 | Rogue agent self-registers with elevated scopes | 2 | 5 | 10 | Medium | IAM Lead | AML.T0073 |
| 14 | T16 | Over-broad vault policy | 2 | 5 | 10 | Medium | Platform Security Lead | AML.T0055 |
| 16 | T15 | LLM quota abuse / DoS | 3 | 3 | 9 | Medium | Head of AI Platform | AML.T0029 |

The live, formula-driven version (with mitigations) is the workbook; if you change any L or I value there, the table above may differ from the sheet's ranks. Treat the workbook as authoritative.

## 5. MITRE ATLAS mapping

| Attack tree | Closest technique | ID | Page |
|---|---|---|---|
| Tree 1: key exfiltration | LLM Prompt Injection: Indirect | AML.T0051.001 | https://atlas.mitre.org/techniques/AML.T0051.001 |
| Tree 2: identity spoofing | Impersonation | AML.T0073 | https://atlas.mitre.org/techniques/AML.T0073 |
| Tree 3: RAG poisoning | RAG Poisoning | AML.T0070 | https://atlas.mitre.org/techniques/AML.T0070 |

Open each page and confirm the ID and name match the live site before submitting; ATLAS is renumbered periodically.

## 6. Screenshot checklist (8 required)

1. **Threat Dragon DFD**: open the imported model; capture the full diagram with boundaries and identity labels.
2. **Threat panel**: click flow F03 (or any flow); capture the threat list showing 3+ STRIDE threats.
3. **draw.io Tree 1**: page 1, goal at top, all nodes visible.
4. **draw.io Tree 2**: page 2.
5. **draw.io Tree 3**: page 3.
6. **STRIDE matrix**: workbook sheet `2_STRIDE_Matrix`, all 12 rows and 6 categories.
7. **Risk register**: sheet `3_Risk_Register`, 16 rows ranked by score.
8. **ATLAS website**: the `AML.T0051.001` page (or T0073 / T0070).

## 7. How to import

- **Threat Dragon**: Open Existing Threat Model, then choose the JSON file (desktop app: File > Open; web app: Local Session > Upload a Threat Model). If a version warning appears, accept it. If layout looks cramped, drag shapes; the data stays intact.
- **draw.io**: app.diagrams.net > File > Open From > Device. Use Arrange > Layout if you want to adjust spacing. Switch pages using the tabs at the bottom.
